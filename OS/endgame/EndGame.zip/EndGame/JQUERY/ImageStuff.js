
/* Werkt voor some reason niet 100% op laptop
$(window).bind('mousewheel', function(event) {
    if (event.originalEvent.wheelDelta <= 0) {
        $(".picture").css("visibility", "hidden");
    }
});
*/

$(document).ready(function(){
    $("#sec1").hover(function(){
        $(".picture").css("visibility", "visible");
    });
  
    $("#sec2").hover(function(){
        $(".picture").css("visibility", "hidden");
    });

    $("#picture").click(function(){
        window.open("https://www.linkedin.com/in/michiel-van-royen-56195619a/");
    });
});