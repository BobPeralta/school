$(document).ready(function(){
    $('#option1').click(function() {
        $('#option1Link')[0].click();
    });

    $('#option2').click(function() {
        $('#option2Link')[0].click();
    });

    $('#option3').click(function() {
        $('#option3Link')[0].click();
    });
});