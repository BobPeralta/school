/* Werkt voor some reason niet 100% op laptop
$(window).bind('mousewheel', function(event) {
    if (event.originalEvent.wheelDelta <= 0) {
        $(".picture").css("visibility", "hidden");
    }
});
*/
var sections = $("#section1,#section2,#section3");

$(document).ready(function(){
    $(sections).hover(function(){
        $(".goback").css("visibility", "visible");
    });
  
    $("#section0").hover(function(){
        $(".goback").css("visibility", "hidden");
    });

    $("#goback").click(function(){
        $(".goback").css("visibility", "hidden");
    });
});
