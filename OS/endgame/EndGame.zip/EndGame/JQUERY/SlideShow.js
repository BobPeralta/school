var speed = 3000;
var run = setInterval("SwitchSlide()", speed);

$(document).ready(function() {
    // Makes img with index number 0 dissapear
    $('#slideshow img:gt(0)').hide();
 
    // Goes back 2 the other image when arrow is pressed
    $('#back').click(function() {
        $('#slideshow img:first').fadeOut(1000);
        $('#slideshow img:last').fadeIn(1000).prependTo('#slideshow');
    });
  
    // Goes 2 the other image when arrow is pressed 
    $('#next').click(function() {
        $('#slideshow img:first').fadeOut(1000).next().fadeIn(1000).end().appendTo('#slideshow');
    });
    
});

// Makes them auto swap
function SwitchSlide()
{
    $('#slideshow img:first').fadeOut(1000).next().show().end().appendTo('#slideshow');

}