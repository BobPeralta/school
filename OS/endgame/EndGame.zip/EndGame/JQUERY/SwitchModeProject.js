var modep = 0;

$(document).ready(function(){
    
    $("#mode").click(function(){
        if (modep == 0){
            $("#project").attr("href","../CSS/project_dark.css");
            $("#portfoliowebsite").attr("src","../IMAGES/portfoliodark.PNG");
            modep = 1;
        }
        else {
            $("#project").attr("href","../CSS/project.css");
            $("#portfoliowebsite").attr("src","../IMAGES/portfolio.PNG");
            modep = 0;
        }
    });

});
