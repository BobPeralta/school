var modec = 0;

function switchModeContact() {
    if (modec == 0){
        document.getElementById("contact").setAttribute("href", "../CSS/contact_dark.css");
        modec = 1;
    }
    else {
        document.getElementById("contact").setAttribute("href", "../CSS/contact.css");
        modec = 0;
    }
}