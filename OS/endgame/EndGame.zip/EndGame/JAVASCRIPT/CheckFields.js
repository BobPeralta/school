function validateForm() {
    var state = true;

    var firstname = document.getElementById("firstname").value;
    var lastname = document.getElementById("lastname").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var question = document.getElementById("question").value;

    document.getElementById("firstname").style.borderColor = "green";
    document.getElementById("lastname").style.borderColor = "green";
    document.getElementById("email").style.borderColor = "green";
    document.getElementById("phone").style.borderColor = "green";
    document.getElementById("question").style.borderColor = "green";
    
    if (firstname == ""){
        state = false;
        document.getElementById("firstname").style.borderColor = "red";
    }

    if (lastname == ""){
        state = false;
        document.getElementById("lastname").style.borderColor = "red";
    }

    if (!email.includes("@",1)){
        state = false;
        document.getElementById("email").style.borderColor = "red";
    }

    if (isNaN(phone) || phone.length < 9){
        state = false;
        document.getElementById("phone").style.borderColor = "red";
    }

    if (question == ""){
        state = false;
        document.getElementById("question").style.borderColor = "red";
    }

    if (state == false){
        document.getElementById("requirement").style.color = "red";
        document.getElementById("requirement").style.fontWeight = "bold";
    }

    return state;
}