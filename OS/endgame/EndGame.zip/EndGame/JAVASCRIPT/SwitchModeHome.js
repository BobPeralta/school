var modeh = 0;

function switchModeHome() {
    if (modeh == 0){
        document.getElementById("css_home").setAttribute("href", "../CSS/home_dark.css");
        modeh = 1;
    }
    else {
        document.getElementById("css_home").setAttribute("href", "../CSS/home.css");
        modeh = 0;
    }
}