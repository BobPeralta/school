var modec = 0;

function switchModeCV() {
    if (modec == 0){
        document.getElementById("cv").setAttribute("href", "../CSS/cv_dark.css");
        modec = 1;
    }
    else {
        document.getElementById("cv").setAttribute("href", "../CSS/cv.css");
        modec = 0;
    }
}