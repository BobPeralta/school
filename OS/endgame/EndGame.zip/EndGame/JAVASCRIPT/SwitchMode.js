var mode = 0;

function switchMode() {
    if (mode == 0){
        document.getElementById("mode").innerHTML = "&#xf186;";
        document.getElementById("css").setAttribute("href", "../CSS/main_dark.css");
        document.getElementById("backgroundvideo").src = "../VIDEOS/background2.mp4";
        mode = 1;
    }
    else {
        document.getElementById("mode").innerHTML = "&#xf185;";
        document.getElementById("css").setAttribute("href", "../CSS/main.css");
        document.getElementById("backgroundvideo").src = "../VIDEOS/backgroundgotg.mp4";

        mode = 0;
    }
}
